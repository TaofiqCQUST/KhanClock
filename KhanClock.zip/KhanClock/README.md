# Khan Clock

Simple clock app for Android: alarms (repeat days, label, snooze), lock-screen ringing screen, and a home screen clock widget showing the next alarm. No external libraries.

Build: push to GitHub; the workflow builds the APK and publishes it on the Releases page.
