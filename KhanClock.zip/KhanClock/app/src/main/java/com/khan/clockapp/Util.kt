package com.khan.clockapp

import android.content.Context
import android.text.format.DateFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object Util {
    fun timeText(ctx: Context, h: Int, m: Int): String {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, h)
        c.set(Calendar.MINUTE, m)
        return DateFormat.getTimeFormat(ctx).format(c.time)
    }

    fun nextAlarmText(ctx: Context): String {
        val now = System.currentTimeMillis()
        val best = AlarmStore.load(ctx).filter { it.enabled }
            .minOfOrNull { AlarmScheduler.nextTrigger(it, now) } ?: return "No alarm set"
        val c = Calendar.getInstance()
        c.timeInMillis = best
        val day = SimpleDateFormat("EEE", Locale.getDefault()).format(c.time)
        return "Next alarm: $day ${DateFormat.getTimeFormat(ctx).format(c.time)}"
    }

    fun daysText(mask: Int): String {
        if (mask == 0) return "Once"
        if (mask == 127) return "Every day"
        if (mask == 31) return "Weekdays"
        if (mask == 96) return "Weekends"
        val names = arrayOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
        return names.filterIndexed { i, _ -> (mask and (1 shl i)) != 0 }.joinToString(", ")
    }

    fun inText(ms: Long): String {
        val total = ms / 60000
        val d = total / 1440
        val h = (total % 1440) / 60
        val m = total % 60
        val parts = ArrayList<String>()
        if (d > 0) parts.add("$d d")
        if (h > 0) parts.add("$h h")
        if (m > 0) parts.add("$m min")
        return if (parts.isEmpty()) "Alarm set for less than a minute from now"
        else "Alarm set for " + parts.joinToString(" ") + " from now"
    }
}
