package com.khan.clockapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator

class AlarmService : Service() {

    companion object {
        const val ACTION_START = "com.khan.clockapp.START"
        const val ACTION_STOP = "com.khan.clockapp.STOP"
        const val ACTION_SNOOZE = "com.khan.clockapp.SNOOZE"
        const val CHANNEL = "alarm_ring"
        const val NOTIF_ID = 42
        const val SNOOZE_MIN = 10
    }

    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var alarmId = -1
    private val handler = Handler(Looper.getMainLooper())
    private val autoStop = Runnable { stopAlarm() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getIntExtra("id", alarmId) ?: alarmId
        when (intent?.action) {
            ACTION_STOP -> stopAlarm()
            ACTION_SNOOZE -> {
                AlarmScheduler.snooze(this, id, SNOOZE_MIN)
                stopAlarm()
            }
            else -> startRinging(id, intent?.getBooleanExtra("snooze", false) ?: false)
        }
        return START_NOT_STICKY
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val ch = NotificationChannel(CHANNEL, "Alarm", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(null, null)
            ch.enableVibration(false)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
        }
    }

    private fun startRinging(id: Int, isSnooze: Boolean) {
        alarmId = id
        val all = AlarmStore.load(this)
        val alarm = all.firstOrNull { it.id == id }
        val title = if (alarm != null && alarm.label.isNotBlank()) alarm.label else "Alarm"
        val whenText = if (alarm != null) Util.timeText(this, alarm.hour, alarm.minute) else ""

        createChannel()
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val ringIntent = Intent(this, RingActivity::class.java)
            .putExtra("id", id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val ringPi = PendingIntent.getActivity(this, 1, ringIntent, flags)
        val stopPi = PendingIntent.getService(
            this, 2,
            Intent(this, AlarmService::class.java).setAction(ACTION_STOP).putExtra("id", id), flags
        )
        val snoozePi = PendingIntent.getService(
            this, 3,
            Intent(this, AlarmService::class.java).setAction(ACTION_SNOOZE).putExtra("id", id), flags
        )

        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(whenText)
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setContentIntent(ringPi)
            .setFullScreenIntent(ringPi, true)
            .addAction(android.R.drawable.ic_media_pause, "Snooze", snoozePi)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPi)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }

        // Alarm was deleted or turned off in the meantime
        if (!isSnooze && (alarm == null || !alarm.enabled)) {
            stopAlarm()
            return
        }

        // Sound
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(this@AlarmService, uri)
                isLooping = true
                prepare()
                start()
            }
        } catch (e: Exception) {
            // no sound available
        }

        // Vibration
        try {
            @Suppress("DEPRECATION")
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            vibrator = v
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 800, 600), 0))
        } catch (e: Exception) {
            // ignore
        }

        // Schedule the next repeat, or switch off a one-time alarm
        if (!isSnooze && alarm != null) {
            if (alarm.days == 0) {
                alarm.enabled = false
                AlarmStore.save(this, all)
            } else {
                AlarmScheduler.schedule(this, alarm)
            }
        }
        ClockWidget.updateAll(this)

        handler.removeCallbacks(autoStop)
        handler.postDelayed(autoStop, 5 * 60 * 1000L)
    }

    private fun releasePlayer() {
        player?.let {
            try { it.stop() } catch (e: Exception) { }
            try { it.release() } catch (e: Exception) { }
        }
        player = null
        vibrator?.cancel()
        vibrator = null
    }

    private fun stopAlarm() {
        handler.removeCallbacks(autoStop)
        releasePlayer()
        sendBroadcast(Intent(RingActivity.ACTION_FINISH).setPackage(packageName))
        stopForeground(STOP_FOREGROUND_REMOVE)
        ClockWidget.updateAll(this)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(autoStop)
        releasePlayer()
        super.onDestroy()
    }
}
