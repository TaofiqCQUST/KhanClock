package com.khan.clockapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val i = Intent(ctx, AlarmService::class.java)
            .setAction(AlarmService.ACTION_START)
            .putExtra("id", intent.getIntExtra("id", -1))
            .putExtra("snooze", intent.getBooleanExtra("snooze", false))
        ctx.startForegroundService(i)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        AlarmScheduler.scheduleAll(ctx)
    }
}
