package com.khan.clockapp

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object AlarmScheduler {
    const val ACTION_FIRE = "com.khan.clockapp.FIRE"

    fun nextTrigger(a: Alarm, from: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = from
        cal.set(Calendar.HOUR_OF_DAY, a.hour)
        cal.set(Calendar.MINUTE, a.minute)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (a.days == 0) {
            if (cal.timeInMillis <= from) cal.add(Calendar.DAY_OF_YEAR, 1)
            return cal.timeInMillis
        }
        for (i in 0..7) {
            val bit = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Mon=0 ... Sun=6
            if ((a.days and (1 shl bit)) != 0 && cal.timeInMillis > from) return cal.timeInMillis
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return cal.timeInMillis
    }

    private fun firePi(ctx: Context, id: Int, snooze: Boolean): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java)
            .setAction(ACTION_FIRE)
            .putExtra("id", id)
            .putExtra("snooze", snooze)
        val code = if (snooze) id + 100000 else id
        return PendingIntent.getBroadcast(
            ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun showPi(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun am(ctx: Context) = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun schedule(ctx: Context, a: Alarm) {
        if (!a.enabled) {
            am(ctx).cancel(firePi(ctx, a.id, false))
            return
        }
        val t = nextTrigger(a)
        am(ctx).setAlarmClock(AlarmManager.AlarmClockInfo(t, showPi(ctx)), firePi(ctx, a.id, false))
    }

    fun cancel(ctx: Context, id: Int) {
        am(ctx).cancel(firePi(ctx, id, false))
        am(ctx).cancel(firePi(ctx, id, true))
    }

    fun snooze(ctx: Context, id: Int, minutes: Int) {
        val t = System.currentTimeMillis() + minutes * 60_000L
        am(ctx).setAlarmClock(AlarmManager.AlarmClockInfo(t, showPi(ctx)), firePi(ctx, id, true))
    }

    fun scheduleAll(ctx: Context) {
        for (a in AlarmStore.load(ctx)) schedule(ctx, a)
        ClockWidget.updateAll(ctx)
    }
}
