package com.khan.clockapp

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView

class RingActivity : Activity() {

    companion object {
        const val ACTION_FINISH = "com.khan.clockapp.FINISH_RING"
    }

    private val finishReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            finish()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val id = intent.getIntExtra("id", -1)
        val alarm = AlarmStore.load(this).firstOrNull { it.id == id }
        val label = if (alarm != null && alarm.label.isNotBlank()) alarm.label else "Alarm"

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            setPadding(dp(32), dp(32), dp(32), dp(32))
        }
        root.addView(TextClock(this).apply {
            format12Hour = "h:mm"
            format24Hour = "HH:mm"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 80f)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        })
        root.addView(TextView(this).apply {
            text = label
            setTextColor(Color.parseColor("#FF9F0A"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(64))
        })

        root.addView(button("Snooze ${AlarmService.SNOOZE_MIN} min", "#3A3A3C") {
            startService(
                Intent(this, AlarmService::class.java)
                    .setAction(AlarmService.ACTION_SNOOZE).putExtra("id", id)
            )
            finish()
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64)).apply {
            bottomMargin = dp(16)
        })
        root.addView(button("Dismiss", "#FF9F0A") {
            startService(
                Intent(this, AlarmService::class.java)
                    .setAction(AlarmService.ACTION_STOP).putExtra("id", id)
            )
            finish()
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(72)))

        setContentView(root)

        val filter = IntentFilter(ACTION_FINISH)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(finishReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(finishReceiver, filter)
        }
    }

    private fun button(text: String, color: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            this.text = text
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                cornerRadius = dp(36).toFloat()
                setColor(Color.parseColor(color))
            }
            isClickable = true
            setOnClickListener { onClick() }
        }

    override fun onDestroy() {
        try { unregisterReceiver(finishReceiver) } catch (e: Exception) { }
        super.onDestroy()
    }
}
