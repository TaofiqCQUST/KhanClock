package com.khan.clockapp

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** days: bit 0 = Monday ... bit 6 = Sunday. 0 means one-time alarm. */
data class Alarm(
    val id: Int,
    var hour: Int,
    var minute: Int,
    var days: Int = 0,
    var enabled: Boolean = true,
    var label: String = ""
)

object AlarmStore {
    private const val PREFS = "alarms"
    private const val KEY = "list"

    fun load(ctx: Context): MutableList<Alarm> {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val out = mutableListOf<Alarm>()
        try {
            val arr = JSONArray(sp.getString(KEY, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Alarm(
                        o.getInt("id"), o.getInt("h"), o.getInt("m"),
                        o.getInt("d"), o.getBoolean("e"), o.optString("l", "")
                    )
                )
            }
        } catch (e: Exception) {
            // ignore corrupt data
        }
        return out
    }

    fun save(ctx: Context, list: List<Alarm>) {
        val arr = JSONArray()
        for (a in list) {
            arr.put(
                JSONObject()
                    .put("id", a.id).put("h", a.hour).put("m", a.minute)
                    .put("d", a.days).put("e", a.enabled).put("l", a.label)
            )
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    fun nextId(list: List<Alarm>): Int = (list.maxOfOrNull { it.id } ?: 0) + 1
}
