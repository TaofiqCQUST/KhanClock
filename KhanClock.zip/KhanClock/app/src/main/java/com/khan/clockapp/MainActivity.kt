package com.khan.clockapp

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.format.DateFormat
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextClock
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import java.util.Calendar

class MainActivity : Activity() {

    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    private val ORANGE = 0xFFFF9F0A.toInt()

    private lateinit var listBox: LinearLayout
    private lateinit var nextText: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        cornerRadius = dp(radiusDp).toFloat()
        setColor(color)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        askPermissions()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun askPermissions() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        if (Build.VERSION.SDK_INT >= 34) {
            val prefs = getSharedPreferences("app", MODE_PRIVATE)
            val nm = getSystemService(NotificationManager::class.java)
            if (!nm.canUseFullScreenIntent() && !prefs.getBoolean("fsi_asked", false)) {
                prefs.edit().putBoolean("fsi_asked", true).apply()
                try {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                            Uri.parse("package:$packageName")
                        )
                    )
                } catch (e: Exception) { }
            }
        }
    }

    private fun buildUi() {
        val frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), 0)
        }

        col.addView(TextClock(this).apply {
            format12Hour = "h:mm"
            format24Hour = "HH:mm"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 64f)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        })
        col.addView(TextClock(this).apply {
            format12Hour = "EEEE, d MMMM"
            format24Hour = "EEEE, d MMMM"
            setTextColor(0xCCFFFFFF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        })
        nextText = TextView(this).apply {
            setTextColor(ORANGE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setPadding(0, dp(6), 0, 0)
        }
        col.addView(nextText)

        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        listBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(20), 0, dp(110))
        }
        scroll.addView(listBox, ViewGroup.LayoutParams(MP, WC))
        col.addView(scroll, LinearLayout.LayoutParams(MP, 0, 1f))
        frame.addView(col, FrameLayout.LayoutParams(MP, MP))

        val fab = TextView(this).apply {
            text = "+"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 34f)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(ORANGE)
            }
            isClickable = true
            setOnClickListener { showEditor(null) }
        }
        frame.addView(
            fab,
            FrameLayout.LayoutParams(dp(64), dp(64), Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(24), dp(28))
            }
        )
        setContentView(frame)
    }

    private fun render() {
        nextText.text = Util.nextAlarmText(this)
        listBox.removeAllViews()
        val all = AlarmStore.load(this).sortedBy { it.hour * 60 + it.minute }
        if (all.isEmpty()) {
            listBox.addView(TextView(this).apply {
                text = "No alarms yet.\nTap + to add one."
                setTextColor(0x99FFFFFF.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setPadding(0, dp(24), 0, 0)
            })
        }
        for (a in all) {
            listBox.addView(alarmRow(a), LinearLayout.LayoutParams(MP, WC).apply {
                bottomMargin = dp(10)
            })
        }
    }

    private fun alarmRow(a: Alarm): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(14), dp(16), dp(14))
            background = rounded(0xFF1C1C1E.toInt(), 18)
            isClickable = true
            setOnClickListener { showEditor(a) }
        }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(TextView(this).apply {
            text = Util.timeText(this@MainActivity, a.hour, a.minute)
            setTextColor(if (a.enabled) Color.WHITE else 0xFF8E8E93.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 34f)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        })
        val sub = if (a.label.isNotBlank()) a.label + " · " + Util.daysText(a.days) else Util.daysText(a.days)
        left.addView(TextView(this).apply {
            text = sub
            setTextColor(0xFF8E8E93.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        })
        row.addView(left, LinearLayout.LayoutParams(0, WC, 1f))

        val sw = Switch(this).apply {
            isChecked = a.enabled
            setOnCheckedChangeListener { _, on ->
                toggleAlarm(a.id, on)
                listBox.post { render() }
            }
        }
        row.addView(sw)
        return row
    }

    private fun toggleAlarm(id: Int, on: Boolean) {
        val all = AlarmStore.load(this)
        val a = all.firstOrNull { it.id == id } ?: return
        a.enabled = on
        AlarmStore.save(this, all)
        AlarmScheduler.schedule(this, a)
        ClockWidget.updateAll(this)
    }

    private fun paintChip(chip: TextView, on: Boolean) {
        chip.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (on) ORANGE else 0xFF3A3A3C.toInt())
        }
    }

    private fun showEditor(existing: Alarm?) {
        val v = layoutInflater.inflate(R.layout.dialog_alarm, null)
        val tp = v.findViewById<TimePicker>(R.id.tp)
        val daysBox = v.findViewById<LinearLayout>(R.id.days)
        val labelEt = v.findViewById<EditText>(R.id.label)

        tp.setIs24HourView(DateFormat.is24HourFormat(this))
        val now = Calendar.getInstance()
        tp.hour = existing?.hour ?: now.get(Calendar.HOUR_OF_DAY)
        tp.minute = existing?.minute ?: now.get(Calendar.MINUTE)
        labelEt.setText(existing?.label ?: "")

        var mask = existing?.days ?: 0
        val names = arrayOf("M", "T", "W", "T", "F", "S", "S")
        for (i in 0..6) {
            val chip = TextView(this).apply {
                text = names[i]
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                isClickable = true
            }
            paintChip(chip, (mask and (1 shl i)) != 0)
            chip.setOnClickListener {
                mask = mask xor (1 shl i)
                paintChip(chip, (mask and (1 shl i)) != 0)
            }
            daysBox.addView(chip, LinearLayout.LayoutParams(dp(38), dp(38)).apply {
                marginStart = dp(3)
                marginEnd = dp(3)
            })
        }

        val b = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(if (existing == null) "New alarm" else "Edit alarm")
            .setView(v)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val all = AlarmStore.load(this)
                val a = if (existing == null) {
                    Alarm(AlarmStore.nextId(all), tp.hour, tp.minute, mask, true, "").also { all.add(it) }
                } else {
                    all.firstOrNull { it.id == existing.id } ?: return@setPositiveButton
                }
                a.hour = tp.hour
                a.minute = tp.minute
                a.days = mask
                a.label = labelEt.text.toString().trim()
                a.enabled = true
                AlarmStore.save(this, all)
                AlarmScheduler.schedule(this, a)
                ClockWidget.updateAll(this)
                render()
                Toast.makeText(
                    this,
                    Util.inText(AlarmScheduler.nextTrigger(a) - System.currentTimeMillis()),
                    Toast.LENGTH_LONG
                ).show()
            }
        if (existing != null) {
            b.setNeutralButton("Delete") { _, _ ->
                AlarmScheduler.cancel(this, existing.id)
                val all = AlarmStore.load(this)
                all.removeAll { it.id == existing.id }
                AlarmStore.save(this, all)
                ClockWidget.updateAll(this)
                render()
            }
        }
        b.show()
    }
}
